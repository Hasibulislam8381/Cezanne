@extends('layouts.frontend.master')
@section('content')
  
@endsection