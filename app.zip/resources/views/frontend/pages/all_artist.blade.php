@extends('layouts.frontend.master')
@section('content')
{{-- bradcrump start --}}
<div class="page-title text-center">
    <div class="contact_tag1 text-center text-bold">Our Talented Artists</div>
    <hr class="hr_for_all">
</div>
{{-- bradcrump end --}}
<section class="all_artist_area clearfix" id="team">
  <div class="container">
      <div class="row">
          <!-- Single Team Member -->
          <div class="col-12 col-sm-12 col-md-6 col-lg-3">
              <a href="" class="">
                  <div class="team_img">
                      
                        <img src="{{ asset('frontend/images/team-img/member1.png') }}" alt="chef-1">
                     
                  </div>
                  <div class="team-content artist_content text-center">
                    
                        <div class="artist_tag1">Md Imran Hossain</div>
                    
                    <div class="artist_tag2">Wood Painter
                    </div>
                </div>

              </a>
          </div>
          <div class="col-12 col-sm-12 col-md-6 col-lg-3">
              <a href="" class="">
                  <div class="team_img">
                      <a href="">
                        <img src="{{ asset('frontend/images/team-img/member2.png') }}" alt="chef-1">
                      </a>

                  </div>
                  <div class="team-content artist_content text-center">
                      
                        <div class="artist_tag1">Md Imran Hossain</div>
                      
                      <div class="artist_tag2">Wood Painter
                      </div>
                  </div>
              </a>
          </div>
          <div class="col-12 col-sm-12 col-md-6 col-lg-3">
              <a href="" class="">
                  <div class="team_img">
                      <img src="{{ asset('frontend/images/team-img/member3.png') }}" alt="chef-1">

                  </div>
                  <div class="team-content artist_content text-center">
                    <div class="artist_tag1">Md Imran Hossain</div>
                    <div class="artist_tag2">Wood Painter
                    </div>
                </div>
              </a>
          </div>
          <div class="col-12 col-sm-12 col-md-6 col-lg-3">
              <a href="" class="">
                  <div class="team_img">
                      <img src="{{ asset('frontend/images/team-img/member3.png') }}" alt="chef-1">

                  </div>
                  <div class="team-content artist_content text-center">
                    <div class="artist_tag1">Md Imran Hossain</div>
                    <div class="artist_tag2">Wood Painter
                    </div>
                </div>
              </a>
          </div>
          <div class="col-12 col-sm-12 col-md-6 col-lg-3">
            <a href="" class="">
                <div class="team_img">
                    <img src="{{ asset('frontend/images/team-img/member1.png') }}" alt="chef-1">
                </div>
                <div class="team-content artist_content text-center">
                  <div class="artist_tag1">Md Imran Hossain</div>
                  <div class="artist_tag2">Wood Painter
                  </div>
              </div>

            </a>
        </div>
        <div class="col-12 col-sm-12 col-md-6 col-lg-3">
          <a href="" class="">
              <div class="team_img">
                  <img src="{{ asset('frontend/images/team-img/member2.png') }}" alt="chef-1">
              </div>
              <div class="team-content artist_content text-center">
                <div class="artist_tag1">Md Imran Hossain</div>
                <div class="artist_tag2">Wood Painter
                </div>
            </div>

          </a>
      </div>
      <div class="col-12 col-sm-12 col-md-6 col-lg-3">
        <a href="" class="">
            <div class="team_img">
                <img src="{{ asset('frontend/images/team-img/member3.png') }}" alt="chef-1">
            </div>
            <div class="team-content artist_content text-center">
              <div class="artist_tag1">Md Imran Hossain</div>
              <div class="artist_tag2">Wood Painter
              </div>
          </div>

        </a>
    </div>
    <div class="col-12 col-sm-12 col-md-6 col-lg-3">
      <a href="" class="">
          <div class="team_img">
              <img src="{{ asset('frontend/images/team-img/member1.png') }}" alt="chef-1">
          </div>
          <div class="team-content artist_content text-center">
            <div class="artist_tag1">Md Imran Hossain</div>
            <div class="artist_tag2">Wood Painter
            </div>
        </div>

      </a>
  </div>

      </div>
  </div>
</section>

@endsection