@extends('layouts.frontend.master')
@section('content')
    {{-- bradcrump start --}}
    <div class="page-title text-center">
        <p class="contact_tag1 text-center text-bold"></p>
    </div>
    {{-- bradcrump end --}}
    <section class="gallery_area">
        <div class="container">
            <div class="row">
                <div class="gallery">
                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/works/image1.png') }}" class="big">
                            <img src="{{ asset('frontend/images/works/image1.png') }}" alt="" title="Image 1">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/works/image2.png') }}" class="big">
                            <img src="{{ asset('frontend/images/works/image2.png') }}" alt="" title="Image 2">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/works/image3.png') }}" class="big">
                            <img src="{{ asset('frontend/images/works/image3.png') }}" alt="" title="Image 3">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/blog/image1.png') }}" class="big">
                            <img src="{{ asset('frontend/images/blog/image1.png') }}" alt="" title="Image 4">
                        </a>
                    </div>
                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/blog/image2.png') }}" class="big">
                            <img src="{{ asset('frontend/images/blog/image2.png') }}" alt="" title="Image 4">
                        </a>
                    </div>
                    <div class="col-lg-4">
                        <a href="{{ asset('frontend/images/blog/image3.png') }}" class="big">
                            <img src="{{ asset('frontend/images/blog/image3.png') }}" alt="" title="Image 4">
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection
