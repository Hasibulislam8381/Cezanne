<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('frontend.index');
    }
    public function product()
    {
        return view('frontend.pages.product');
    }
    public function artist()
    {
        return view('frontend.pages.artist');
    }
    public function all_blogs()
    {
        return view('frontend.pages.all_blogs');
    }
    public function blog_details()
    {
        return view('frontend.pages.blog_details');
    }
    public function all_works()
    {
        return view('frontend.pages.all_works');
    }
    public function all_artist()
    {
        return view('frontend.pages.all_artist');
    }
    public function all_glance()
    {
        return view('frontend.pages.all_glance');
    }
    public function carts()
    {
        return view('frontend.pages.carts');
    }
    public function wishlist()
    {
        return view('frontend.pages.wishlist');
    }
    public function frame()
    {
        return view('frontend.pages.frame');
    }
    public function exhibition()
    {
        return view('frontend.pages.exhibition');
    }
    public function gallery()
    {
        return view('frontend.pages.gallery');
    }
    public function user_dashboard()
    {
        return view('frontend.user.index');
    }
    public function user_profile()
    {
        return view('frontend.user.profile');
    }
    public function checkout()
    {
        return view('frontend.pages.checkout');
    }
    public function privacy()
    {
        return view('frontend.pages.privacy');
    }
    public function terms_and_condition()
    {
        return view('frontend.pages.terms_and_condition');
    }
    public function return_policy()
    {
        return view('frontend.pages.return_policy');
    }
    public function purchaseHistory()
    {
        return view('frontend.user.purchaseHistory');
    }
    public function orderView()
    {
        return view('frontend.user.order_view');
    }
  
}
