<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great !
|
*/


Auth::routes();

Route::controller(HomeController::class)->group(function(){
    Route::get('/', 'index')->name('index');
    Route::get('/product', 'product')->name('product');
    Route::get('/artist', 'artist')->name('artist');
    Route::get('/all-blogs', 'all_blogs')->name('all_blogs');
    Route::get('/blog-details', 'blog_details')->name('blog_details');
    Route::get('/all-works', 'all_works')->name('all_works');
    Route::get('/all-artist', 'all_artist')->name('all_artist');
    Route::get('/all-glance', 'all_glance')->name('all_glance');
    Route::get('/carts', 'carts')->name('carts');
    Route::get('/wishlist', 'wishlist')->name('wishlist');
    Route::get('/frame', 'frame')->name('frame');
    Route::get('/exhibition', 'exhibition')->name('exhibition');
    Route::get('/gallery', 'gallery')->name('gallery');
    Route::get('/user-dashboard', 'user_dashboard')->name('user_dashboard');
    Route::get('/user-dashboard/purchaseHistory', 'purchaseHistory')->name('purchaseHistory');
    Route::get('/user-dashboard/order-view', 'orderView')->name('orderView');
    Route::get('/user-dashboard/profile', 'user_profile')->name('user_profile');
    Route::get('/checkout', 'checkout')->name('checkout');
    Route::get('/privacy', 'privacy')->name('privacy');
    Route::get('/terms_and_condition', 'terms_and_condition')->name('terms_and_condition');
    Route::get('/return_policy', 'return_policy')->name('return_policy');

});

