
<?php $__env->startSection('content'); ?>

<div class="page-title text-center">
    <div class="contact_tag1 text-center text-bold">All Works</div>
    <hr class="hr_for_all">
</div>

  <!-- ##### Works Area Start ##### -->
<section class="all_works_area">
  <div class="container">

      <div class="row">
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 4.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 3.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 2.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 4.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 3.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4">
              <!-- Content -->
              <div class="service_single_content text-center wow fadeInUp" data-wow-delay="0.2s">

                  <div class="serv_icon">
                      <img src="<?php echo e(asset('frontend/images/works/image 2.png')); ?>" alt="">
                  </div>
                  <div class="service-content text-center">
                      <div class="artist">
                          Artists
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
<!-- ##### Works Area Start ##### -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cezanne\resources\views/frontend/pages/all_works.blade.php ENDPATH**/ ?>