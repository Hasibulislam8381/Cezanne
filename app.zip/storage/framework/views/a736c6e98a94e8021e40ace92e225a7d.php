<?php $__env->startSection('content'); ?>

<div class="page-title text-center">
    <div class="contact_tag1 text-center text-bold">Your Wishlist</div>
    <hr class="hr_for_all">
</div>

    <div class="carts_page">
        
        <div class="container">
            <div class="carts_table">
                <table style="text-align: center" class="table">
                    <thead style="background-color: #644700;color:white" class="">
                        <tr>
                            <th scope="col">Product Id</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Image</th>
                            <th scope="col">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>345 BDT</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Larry</td>
                            <td>894 BDT</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="buynow_return">
                <div class="return_shop">
                    <a href="" style="color: #644700"><i class="fa-solid fa-arrow-right fa-rotate-180"></i> Return to
                        shop</a>
                </div>
                <div class="cart_buy_now">
                    <a href=""><button><i class="fa-solid fa-bag-shopping fa-bounce"></i> Buy Now</button></a>
                    <a href=""><button><i class="fa-solid fa-cart-shopping fa-bounce"></i></i> Add to
                            cart</button></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cezanne\resources\views/frontend/pages/wishlist.blade.php ENDPATH**/ ?>