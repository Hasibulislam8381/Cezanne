
<?php $__env->startSection('content'); ?>
    
    <div class="page-title text-center">
        <p class="contact_tag1 text-center text-bold"></p>
    </div>
    
    <section class="gallery_area">
        <div class="container">
            <div class="row">
                <div class="gallery">
                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/works/image1.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/works/image1.png')); ?>" alt="" title="Image 1">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/works/image2.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/works/image2.png')); ?>" alt="" title="Image 2">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/works/image3.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/works/image3.png')); ?>" alt="" title="Image 3">
                        </a>
                    </div>

                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/blog/image1.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/blog/image1.png')); ?>" alt="" title="Image 4">
                        </a>
                    </div>
                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/blog/image2.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/blog/image2.png')); ?>" alt="" title="Image 4">
                        </a>
                    </div>
                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('frontend/images/blog/image3.png')); ?>" class="big">
                            <img src="<?php echo e(asset('frontend/images/blog/image3.png')); ?>" alt="" title="Image 4">
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cezanne\resources\views/frontend/pages/gallery.blade.php ENDPATH**/ ?>