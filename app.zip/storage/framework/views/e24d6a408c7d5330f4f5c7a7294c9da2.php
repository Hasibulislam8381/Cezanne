<!-- ##### Welcome Area Start ##### -->

<section class="home-slider">
    <div class="flexslider">
        <ul class="slides">
            <div class="row">
                <div class="banner_slides owl-carousel">
                    <div class="col-md-12">
                        <img src=" <?php echo e(asset('frontend/images/bg-img/slider1.png')); ?>" alt="Slider 1" />
                        <div class="slider-content">
                            <div class="container">
                                <div class="slider-text">
                                    <h1>Get Recommendations</h1>
                                    <p>Work with an Art Advisor to Find Your Perfect Artwork</p>
                                    <center><a class="buy" href="#">Buy Now</a></center>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <img src=" <?php echo e(asset('frontend/images/bg-img/slider1.png')); ?>" alt="Slider 1" />
                        <div class="slider-content">
                            <div class="container">
                                <div class="slider-text">
                                    <h1>Get Recommendations Two</h1>
                                    <p>Work with an Art Advisor to Find Your Perfect Artwork</p>
                                    <center><a class="buy" href="#">Buy Now</a></center>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <img src=" <?php echo e(asset('frontend/images/bg-img/slider1.png')); ?>" alt="Slider 1" />
                        <div class="slider-content">
                            <div class="container">
                                <div class="slider-text">
                                    <h1>Get Recommendations Three</h1>
                                    <p>Work with an Art Advisor to Find Your Perfect Artwork</p>
                                    <center><a class="buy" href="#">Buy Now</a></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





        </ul>
    </div>
</section>
<!-- ##### Welcome Area End ##### -->
<?php /**PATH C:\laragon\www\Cezanne\resources\views/frontend/banner.blade.php ENDPATH**/ ?>