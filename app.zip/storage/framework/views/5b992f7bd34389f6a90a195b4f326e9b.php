<!-- ##### Footer Area Start ##### -->
<footer class="footer-area bg-img">
    <div class="container">
        <div class="footer_upper_part">
            <div class="footer_border">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="footer_logo">
                            <img src="<?php echo e(asset('frontend/images/logo/Logo.png')); ?>" alt="">

                        </div>
                        <div class="footer_des">
                            <h5>Cezanne</h5>
                            Korem ipsum dolor sit amet, consectetur adipiscing elit. Korem ipsum dolor sit amet,
                            consectetur
                            adipiscing elit.Korem ipsum dolor sit amet, consectetur adipiscing elit.
                        </div>

                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="quick_contact">
                            <h5>Quick Contact</h5>
                            <div class="footer_menu_link">
                                <a href="#">Works</a>
                                <a href="#">Frame</a>
                                <a href="#">Gallery</a>
                                <a href="#">Blog</a>
                                <a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a>
                                <a href="<?php echo e(route('terms_and_condition')); ?>">Terms and Condition</a>
                                <a href="<?php echo e(route('return_policy')); ?>">Return Policy</a>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="quick_contact">
                            <h5>Contact Me</h5>
                            <div class="footer_menu_link">
                                <a href="mailto:info@cezanne.com"><i class="fa fa-envelope" aria-hidden="true"></i><span
                                        class="contact_info">info@cezanne.com</span></a>
                                <a href="tel:+880 1636 558 227"><i class="fa fa-phone" aria-hidden="true"></i><span
                                        class="contact_info">+880 1636 558 227</span></a>
                                <a href="#" class="">
                                    <table>
                                        <tr>
                                            <td><i class="fa fa-map-marker location" aria-hidden="true"></i></td>
                                            <td class="add_info">House: 02, Road: 07, Baridhara
                                                    J Block
                                                    Dhaka-1212, Bangladesh.</td>
                                        </tr>
                                    </table>
                                </a>
                            </div>
                            <div class="social_link">
                                <a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"> <i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#" class="youtube"><i class="fa fa-youtube-play"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="footer_lower_part">
        <div class="container">
            <div class="f_border_bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="subscribe">Subscribe, For Weekly Updates</div>
                    </div>
                    <div class="col-lg-6">
                        <div class="footer_input_field">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control footer_input"
                                    placeholder="Enter Your Email*">
                                <a href="" class="input-group-text footer_signup text-uppercase" id="basic-addon2">SignUp
                                    Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="copyright">
                    &copy; Copyright reserved Cezanne. Designed By <a href="https://www.techdynobd.com/" class="tdbd_url">Techdyno BD
                        Ltd</a> All Rights Reserved
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- ##### Footer Area End ##### -->
<?php /**PATH C:\laragon\www\Cezanne\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>