<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Cezanne</title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('frontend/images/logo/Logo.png')); ?>">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/lightgallery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/simple-lightbox.min.css')); ?>">




    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <script src="https://kit.fontawesome.com/03f25eb302.js" crossorigin="anonymous"></script>

    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body class="light-version">
    <!-- Preloader -->
    <div id="preloader">
        <div class="preload-content">
            <div id="loader-load"></div>
        </div>
    </div>

    <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ########## All JS ########## -->
    <!-- jQuery js -->
    <script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>

    <!-- Popper js -->
    <script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <!-- All Plugins js -->
    <script src="<?php echo e(asset('frontend/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/simple-lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/simple-lightbox.legacy.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/simple-lightbox.jquery.min.js')); ?>"></script>


    <script src="<?php echo e(asset('frontend/js/lightgallery-all.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#lightgallery').lightGallery();
        });
    </script>
    <script>
        var gallery = $('.gallery a').simpleLightbox({
            sourceAttr:'href',

            nav:true,
            overlay:true,
            close:true,
            closeText:'X',
            swipeClose:true,
            showCounter:true,
            fileExt:'png|jpg|jpeg|gif',


        })
    </script>
    <!-- script js -->
    <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script'); ?>


</body>

</html>
<?php /**PATH C:\laragon\www\Cezanne\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>