<?php $__env->startSection('content'); ?>

<div class="page-title text-center">
    <div class="contact_tag1 text-center text-bold">Your All Carts</div>
    <hr class="hr_for_all">
</div>

    <div class="carts_page">
        <div class="container">
            <div class="carts_table table-responsive">
                <table style="text-align: center" class="table">
                    <thead style="background-color: #644700;color:white" class="">
                        <tr>
                            <th scope="col">Serial</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Price</th>
                            <th scope="col">Image</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>345 BDT</td>
                            <td>3</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td>5</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td>5</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>567 BDT</td>
                            <td>2</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Larry</td>
                            <td>894 BDT</td>
                            <td>1</td>
                            <td></td>
                            <td><a href=""><button class="btn btn-danger"><i
                                            class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="carts_table2 table-responsive">
                <table class="table">
            
                    <tbody>
                        <tr style="background-color: #644700;color:white">
                            <th  scope="row">Serial</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Product name</th>
                            <td>T-Shirt</td>
                        </tr>
                        <tr>
                            <th scope="row">Quantity</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Price</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Image</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row">Action</th>
                            <td><a href=""><button class="btn btn-danger"><i
                                class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                       
                       
                        
                      
                    </tbody>
                    <tbody >
                        <tr style="background-color: #644700;color:white">
                            <th  scope="row">Serial</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Product name</th>
                            <td>T-Shirt</td>
                        </tr>
                        <tr>
                            <th scope="row">Quantity</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Price</th>
                            <td>03</td>
                        </tr>
                        <tr>
                            <th scope="row">Image</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row">Action</th>
                            <td><a href=""><button class="btn btn-danger"><i
                                class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                       
                       
                        
                      
                    </tbody>
                    <tbody>
                        <tr style="background-color: #644700;color:white">
                            <th  scope="row">Serial</th>
                            <td>03</td>
                        </tr>
                        <tr>
                            <th scope="row">Product name</th>
                            <td>T-Shirt</td>
                        </tr>
                        <tr>
                            <th scope="row">Quantity</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Price</th>
                            <td>01</td>
                        </tr>
                        <tr>
                            <th scope="row">Image</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row">Action</th>
                            <td><a href=""><button class="btn btn-danger"><i
                                class="fa-solid fa-trash"></i></button></a></td>
                        </tr>
                       
                       
                        
                      
                    </tbody>
                </table>
            </div>
            
            <div class="buynow_return">
                <div class="return_shop">
                    <a href="" style="color: #644700"><i class="fa-solid fa-arrow-right fa-rotate-180"></i> Return to
                        shop</a>
                </div>
                <div class="cart_buy_now">
                    <a href=""><button><i class="fa-solid fa-bag-shopping fa-bounce"></i> Buy Now</button></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Cezanne\resources\views/frontend/pages/carts.blade.php ENDPATH**/ ?>